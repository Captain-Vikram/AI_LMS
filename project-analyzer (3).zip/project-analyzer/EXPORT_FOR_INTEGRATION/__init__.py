"""
Project Analyzer - AI-Powered Code Review System

This module provides AI-powered analysis of software projects using:
- Google Gemini API (cloud-based, requires API key)
- LM Studio (local, free, offline)

Usage:
    from analyzer import ProjectAnalyzer
    analyzer = ProjectAnalyzer()
    result = await analyzer.analyze_project(files_data, analysis_request)
"""

from analyzer import ProjectAnalyzer
from github_utils import GitHubUtils
from models import AnalysisRequest, AnalysisResponse

__version__ = "1.0.0"
__all__ = ["ProjectAnalyzer", "GitHubUtils", "AnalysisRequest", "AnalysisResponse"]
