from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import shutil
import os
import zipfile
from pathlib import Path
from typing import Optional
import uvicorn

from analyzer import ProjectAnalyzer
from github_utils import GitHubUtils

app = FastAPI(title="AI-Powered Code Review Assistant")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create uploads directory
UPLOAD_DIR = Path("./uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# Initialize utilities
analyzer = ProjectAnalyzer()
github_utils = GitHubUtils()

# Mount static files (frontend)
frontend_path = Path(__file__).parent.parent / "frontend"
if frontend_path.exists():
    app.mount("/static", StaticFiles(directory=str(frontend_path)), name="static")

@app.get("/")
async def root():
    # Serve index.html
    index_path = Path(__file__).parent.parent / "frontend" / "index.html"
    if index_path.exists():
        return FileResponse(str(index_path))
    return {
        "message": "AI-Powered Code Review Assistant API",
        "status_url": "/status",
    }

@app.get("/favicon.ico")
async def favicon():
    return JSONResponse(content={}, status_code=204)

@app.get("/status")
async def status():
    """Check Gemini and LM Studio availability."""
    return analyzer.get_status()

@app.post("/analyze/zip")
async def analyze_zip_file(
    file: UploadFile = File(...),
    project_topic: Optional[str] = Form(None),
    problem_statement: Optional[str] = Form(None),
    custom_requirements: Optional[str] = Form(None)
):
    """Analyze uploaded zip file"""
    temp_zip_path = None
    extract_path = None
    
    try:
        # Validate file
        if not file.filename.endswith('.zip'):
            raise HTTPException(status_code=400, detail="Only ZIP files are allowed")
        
        safe_name = Path(file.filename).name
        # Save uploaded zip
        temp_zip_path = UPLOAD_DIR / safe_name
        with open(temp_zip_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Extract zip
        extract_path = UPLOAD_DIR / f"extracted_{safe_name.replace('.zip', '')}"
        extract_path.mkdir(exist_ok=True)
        
        with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
            _safe_extract_zip(zip_ref, extract_path)
        
        # Read project files
        files_data = await read_project_files(extract_path)
        
        if not files_data:
            raise HTTPException(status_code=400, detail="No readable files found in ZIP")
        
        # Prepare analysis request
        analysis_req = {
            'project_topic': project_topic,
            'problem_statement': problem_statement,
            'custom_requirements': _split_requirements(custom_requirements)
        }
        
        # Analyze project
        result = await analyzer.analyze_project(files_data, analysis_req)
        
        return JSONResponse(content=result)
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # Cleanup
        if temp_zip_path and temp_zip_path.exists():
            temp_zip_path.unlink()
        if extract_path and extract_path.exists():
            shutil.rmtree(extract_path)

@app.post("/analyze/github")
async def analyze_github_repo(
    repo_url: str = Form(...),
    branch: Optional[str] = Form("main"),
    project_topic: Optional[str] = Form(None),
    problem_statement: Optional[str] = Form(None),
    custom_requirements: Optional[str] = Form(None)
):
    """Analyze GitHub repository"""
    repo_path = None
    
    try:
        # Validate URL
        if not repo_url.startswith('https://github.com/') and not repo_url.startswith('http://github.com/'):
            raise HTTPException(status_code=400, detail="Invalid GitHub URL")
        
        # Clone repository
        repo_path = await github_utils.clone_repository(repo_url, branch)
        
        # Read project files
        files_data = await github_utils.read_project_files(repo_path)
        
        if not files_data:
            raise HTTPException(status_code=400, detail="No readable files found in repository")
        
        # Prepare analysis request
        analysis_req = {
            'project_topic': project_topic,
            'problem_statement': problem_statement,
            'custom_requirements': _split_requirements(custom_requirements)
        }
        
        # Analyze project
        result = await analyzer.analyze_project(files_data, analysis_req)
        
        return JSONResponse(content=result)
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        # Cleanup
        if repo_path and Path(repo_path).exists():
            await github_utils.cleanup(repo_path)

def _split_requirements(value: Optional[str]) -> list:
    if not value:
        return []
    return [item.strip() for item in value.split(',') if item.strip()]


def _safe_extract_zip(zip_ref: zipfile.ZipFile, destination: Path) -> None:
    destination = destination.resolve()
    for member in zip_ref.infolist():
        member_path = (destination / member.filename).resolve()
        if destination != member_path and destination not in member_path.parents:
            raise HTTPException(status_code=400, detail="ZIP contains unsafe file paths")
    zip_ref.extractall(destination)


async def read_project_files(project_path: Path) -> list:
    """Read all project files from path"""
    files_data = []
    exclude_extensions = {
        '.pyc', '.pyo', '.so', '.dll', '.exe', '.jpg', '.jpeg', '.png', '.gif',
        '.webp', '.ico', '.mp4', '.mp3', '.wav', '.zip', '.tar', '.rar', '.7z',
        '.pdf', '.woff', '.woff2', '.ttf'
    }
    exclude_dirs = {'node_modules', '__pycache__', 'dist', 'build', '.git', '.venv', 'env', '.next', 'coverage'}
    
    for file_path in project_path.rglob("*"):
        # Skip excluded directories
        if any(excluded in file_path.parts for excluded in exclude_dirs):
            continue
        
        if file_path.is_file():
            extension = file_path.suffix.lower()
            
            if extension in exclude_extensions:
                continue
            
            # Skip files larger than 1MB
            if file_path.stat().st_size > 1024 * 1024:
                continue
            
            try:
                # Try to read as text
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                relative_path = str(file_path.relative_to(project_path))
                files_data.append({
                    'path': relative_path,
                    'content': content,
                    'size': len(content),
                    'extension': extension
                })
            except (UnicodeDecodeError, Exception):
                # Skip binary files
                continue
    
    return files_data

if __name__ == "__main__":
    print("="*50)
    print(">> Starting AI-Powered Code Review Assistant")
    print("="*50)
    status_data = analyzer.get_status()
    print(f"   Gemini Configured: {'Yes' if status_data['primary']['configured'] else 'No'}")
    print(f"   LM Studio Status: {'Connected' if status_data['fallback']['connected'] else 'Disconnected'}")
    print(f"   API Server: http://localhost:8000")
    print(f"   Status Check: http://localhost:8000/status")
    print("="*50)
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
