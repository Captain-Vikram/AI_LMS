# backend/analyzer.py - Complete Working Version
import os
import json
import requests
from typing import List, Dict, Any
from dotenv import load_dotenv

load_dotenv()

class ProjectAnalyzer:
    def __init__(self):
        self.local_llm_url = os.getenv('LOCAL_LLM_URL', 'http://localhost:1234')
        self.model_name = os.getenv('MODEL_NAME', 'deepseek/deepseek-r1-0528-qwen3-8b')
        self.temperature = float(os.getenv('MODEL_TEMPERATURE', '0.7'))
        self.max_tokens = int(os.getenv('MODEL_MAX_TOKENS', '4000'))
        
        # Check connection to LM Studio
        self.is_available = self._check_connection()
        
        if self.is_available:
            print(f"✅ Connected to LM Studio at {self.local_llm_url}")
            print(f"📦 Using model: {self.model_name}")
        else:
            print(f"⚠️ Could not connect to LM Studio")
    
    def _check_connection(self) -> bool:
        """Check if LM Studio server is running"""
        try:
            response = requests.get(f"{self.local_llm_url}/v1/models", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    async def analyze_project(self, files_data: List[Dict], analysis_request: Dict) -> Dict:
        """Analyze project using LM Studio local model"""
        
        if not self.is_available:
            return self._get_fallback_response("LM Studio not connected")
        
        if not files_data:
            return self._get_fallback_response("No files to analyze")
        
        # Prepare project context
        project_context = self._prepare_context(files_data)
        
        # Build prompt
        prompt = self._build_analysis_prompt(project_context, analysis_request)
        
        try:
            # Prepare request
            payload = {
                "model": self.model_name,
                "messages": [
                    {
                        "role": "system", 
                        "content": "You are an expert code analyzer. Always respond with valid JSON only, no other text."
                    },
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ],
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "stream": False
            }
            
            # Make request to LM Studio
            response = requests.post(
                f"{self.local_llm_url}/v1/chat/completions",
                json=payload,
                timeout=120,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                if 'choices' in result and len(result['choices']) > 0:
                    ai_response = result['choices'][0]['message']['content']
                    structured_response = self._parse_response(ai_response, files_data)
                    return structured_response
                else:
                    return self._get_fallback_response("Invalid response format from LM Studio")
            else:
                return self._get_fallback_response(f"LM Studio error: HTTP {response.status_code}")
            
        except requests.exceptions.Timeout:
            return self._get_fallback_response("Request timeout - model might be too slow. Try a smaller model.")
        except Exception as e:
            print(f"Error: {e}")
            return self._get_fallback_response(f"Analysis error: {str(e)}")
    
    def _prepare_context(self, files_data: List[Dict]) -> str:
        """Prepare context for LLM"""
        context_parts = []
        
        # Basic stats
        context_parts.append(f"Total files: {len(files_data)}")
        
        # File types
        file_types = {}
        for file in files_data:
            ext = file['extension'][1:] if file['extension'].startswith('.') else 'no_ext'
            file_types[ext] = file_types.get(ext, 0) + 1
        
        context_parts.append("File types: " + ", ".join([f"{k}:{v}" for k, v in file_types.items()]))
        
        # File contents (limit to first 5 important files)
        context_parts.append("\nFile contents:")
        count = 0
        for file in files_data[:5]:  # Limit to first 5 files
            context_parts.append(f"\n--- {file['path']} ---")
            context_parts.append(file['content'][:1500])  # Limit content
            count += 1
            if count >= 5:
                break
        
        return "\n".join(context_parts)
    
    def _build_analysis_prompt(self, context: str, analysis_request: Dict) -> str:
        """Build analysis prompt"""
        return f"""Analyze this project and return ONLY valid JSON.

Project files:
{context}

Requirements:
Topic: {analysis_request.get('project_topic', 'Not specified')}
Problem: {analysis_request.get('problem_statement', 'Not specified')}
Custom: {analysis_request.get('custom_requirements', [])}

Return JSON:
{{
    "project_topic_identification": {{
        "identified_topic": "brief description",
        "main_technologies": ["tech1", "tech2"],
        "project_complexity": "Beginner/Intermediate/Advanced",
        "estimated_completion_percentage": 50
    }},
    "problem_statement_match_score": 75,
    "match_analysis": "analysis text",
    "good_features": ["feature 1", "feature 2"],
    "improvement_suggestions": [
        {{
            "area": "area name",
            "current_issue": "issue",
            "suggestion": "suggestion",
            "priority": "High/Medium/Low"
        }}
    ],
    "code_quality_score": 70,
    "technical_debt_areas": ["area1", "area2"],
    "recommendations": ["rec1", "rec2"],
    "summary": "overall summary"
}}"""
    
    def _parse_response(self, response: str, files_data: List[Dict]) -> Dict:
        """Parse JSON response"""
        try:
            # Clean response - remove markdown code blocks if present
            response = response.strip()
            if response.startswith('```json'):
                response = response[7:]
            if response.startswith('```'):
                response = response[3:]
            if response.endswith('```'):
                response = response[:-3]
            
            # Find JSON
            start = response.find('{')
            end = response.rfind('}') + 1
            if start != -1 and end > start:
                json_str = response[start:end]
                result = json.loads(json_str)
            else:
                result = json.loads(response)
            
            # Add file stats
            result['file_statistics'] = {
                'total_files': len(files_data),
                'total_size_kb': round(sum(f['size'] for f in files_data) / 1024, 2)
            }
            
            return result
        except Exception as e:
            print(f"Parse error: {e}")
            return self._get_fallback_response(f"Parse error: {str(e)}")
    
    def _get_fallback_response(self, error_message: str) -> Dict:
        """Fallback response"""
        return {
            "project_topic_identification": {
                "identified_topic": "Analysis Error",
                "main_technologies": ["Error"],
                "project_complexity": "Unknown",
                "estimated_completion_percentage": 0
            },
            "problem_statement_match_score": 0,
            "match_analysis": error_message,
            "good_features": ["Unable to analyze"],
            "improvement_suggestions": [],
            "code_quality_score": 0,
            "technical_debt_areas": [],
            "recommendations": ["Check LM Studio connection and try again"],
            "summary": error_message,
            "file_statistics": {
                "total_files": 0,
                "total_size_kb": 0
            }
        }