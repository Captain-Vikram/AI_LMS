from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AnalysisRequest(BaseModel):
    project_topic: Optional[str] = None
    problem_statement: Optional[str] = None
    custom_requirements: List[str] = Field(default_factory=list)


class FileInfo(BaseModel):
    path: str
    content: str
    size: int
    extension: str


class ExecutiveSummary(BaseModel):
    what_user_built: str = ""
    what_was_expected: str = ""
    match_percentage: int = 0
    overall_verdict: str = "Needs Improvement"


class RequirementChecklistItem(BaseModel):
    requirement: str = ""
    status: str = "Missing"
    location: str = "Not found"
    quality: str = "N/A"
    notes: str = ""


class GoodFeature(BaseModel):
    feature: str = ""
    location: str = ""
    why_good: str = ""


class ImprovementNeeded(BaseModel):
    missing_requirement: str = ""
    suggestion: str = ""
    file_to_add: str = ""
    code_example: str = ""
    priority: str = "Medium"
    effort_hours: Any = 0


class CodeQualityIssue(BaseModel):
    issue: str = ""
    location: str = ""
    problem: str = ""
    suggestion: str = ""
    priority: str = "Medium"


class FinalScore(BaseModel):
    total: int = 0
    grade: str = "N/A"
    summary: str = ""


class FileStatistics(BaseModel):
    total_files: int = 0
    file_types: Dict[str, int] = Field(default_factory=dict)
    total_size_kb: float = 0
    reviewed_file_limit: int = 15
    reviewed_chars_per_file: int = 2000


class AnalysisResult(BaseModel):
    executive_summary: ExecutiveSummary = Field(default_factory=ExecutiveSummary)
    requirements_checklist: List[RequirementChecklistItem] = Field(default_factory=list)
    good_features: List[GoodFeature] = Field(default_factory=list)
    improvements_needed: List[ImprovementNeeded] = Field(default_factory=list)
    code_quality_issues: List[CodeQualityIssue] = Field(default_factory=list)
    final_score: FinalScore = Field(default_factory=FinalScore)
    file_statistics: FileStatistics = Field(default_factory=FileStatistics)
    ai_provider: str = ""


class GitHubAnalysisRequest(BaseModel):
    repo_url: str
    branch: Optional[str] = "main"
    analysis_request: AnalysisRequest = Field(default_factory=AnalysisRequest)
