import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).with_name(".env"), override=True)


class ProjectAnalyzer:
    def __init__(self):
        self.gemini_api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.gemini_model = os.getenv("GEMINI_MODEL", "auto").strip() or "auto"
        self.gemini_api_base = "https://generativelanguage.googleapis.com/v1beta"
        self._resolved_gemini_model: Optional[str] = None
        self._available_gemini_models: Optional[List[str]] = None

        self.local_llm_url = os.getenv("LOCAL_LLM_URL", "http://localhost:1234")
        self.model_name = os.getenv("MODEL_NAME", "qwen2.5-coder-3b-instruct")
        self.temperature = float(os.getenv("MODEL_TEMPERATURE", "0.2"))
        self.max_tokens = int(os.getenv("MODEL_MAX_TOKENS", "3000"))
        self.local_max_tokens = int(os.getenv("LOCAL_MODEL_MAX_TOKENS", "1000"))
        self.local_prompt_char_budget = int(os.getenv("LOCAL_PROMPT_CHAR_BUDGET", "3800"))
        self.chunk_char_budget = int(os.getenv("CHUNK_CHAR_BUDGET", "2200"))
        self.max_chunks = int(os.getenv("MAX_REVIEW_CHUNKS", "20"))

        self.lm_studio_available = self._check_lm_studio()
        self.is_available = bool(self.gemini_api_key) or self.lm_studio_available

        print(f"[AI] Gemini configured: {'yes' if self.gemini_api_key else 'no'}")
        print(f"[AI] LM Studio connected: {'yes' if self.lm_studio_available else 'no'}")

    def _check_lm_studio(self) -> bool:
        try:
            response = requests.get(f"{self.local_llm_url}/v1/models", timeout=4)
            return response.status_code == 200
        except requests.RequestException:
            return False

    def get_status(self) -> Dict[str, Any]:
        self.lm_studio_available = self._check_lm_studio()
        self.is_available = bool(self.gemini_api_key) or self.lm_studio_available
        return {
            "available": self.is_available,
            "primary": {
                "provider": "Google Gemini",
                "configured": bool(self.gemini_api_key),
                "model": self._resolved_gemini_model or self.gemini_model,
            },
            "fallback": {
                "provider": "LM Studio",
                "connected": self.lm_studio_available,
                "model": self.model_name,
                "url": f"{self.local_llm_url}/v1",
            },
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "local_max_tokens": self.local_max_tokens,
            "local_prompt_char_budget": self.local_prompt_char_budget,
            "chunk_char_budget": self.chunk_char_budget,
            "max_review_chunks": self.max_chunks,
        }

    async def analyze_project(self, files_data: List[Dict], analysis_request: Dict) -> Dict:
        if not files_data:
            return self._error_response(
                "No readable files were found. Upload a ZIP or repository that contains text source files under 1MB."
            )

        gemini_prompt = self._build_prompt(files_data, analysis_request, compact=False)
        local_prompt = self._build_prompt(files_data, analysis_request, compact=True)
        provider_errors = []
        gemini_analysis = None
        gemini_error = None
        lm_analysis = None
        lm_error = None

        if self.gemini_api_key:
            gemini_result, gemini_error = self._call_gemini(gemini_prompt)
            if gemini_result:
                parsed = self._parse_ai_json(gemini_result, files_data, "gemini")
                if parsed:
                    gemini_analysis = self._complete_analysis(parsed, files_data, analysis_request, "gemini")
                repair = None if gemini_analysis else self._repair_with_provider("gemini", gemini_result)
                if repair:
                    parsed = self._parse_ai_json(repair, files_data, "gemini")
                    if parsed:
                        gemini_analysis = self._complete_analysis(parsed, files_data, analysis_request, "gemini")
                if not gemini_analysis:
                    gemini_error = "Gemini returned invalid JSON."
                    provider_errors.append(gemini_error)
            else:
                gemini_error = f"Gemini failed: {gemini_error}"
                provider_errors.append(gemini_error)
        else:
            gemini_error = "Gemini skipped: set GEMINI_API_KEY to enable the primary service."
            provider_errors.append(gemini_error)

        self.lm_studio_available = self._check_lm_studio()
        if self.lm_studio_available:
            chunked_result, chunked_error = self._analyze_with_lm_studio_chunks(files_data, analysis_request)
            if chunked_result:
                lm_analysis = self._complete_analysis(chunked_result, files_data, analysis_request, chunked_result.get("ai_provider", "lm_studio_chunked"))

            local_result, local_error = (None, None) if lm_analysis else self._call_lm_studio(local_prompt)
            if local_result and not lm_analysis:
                parsed = self._parse_ai_json(local_result, files_data, "lm_studio")
                if parsed:
                    lm_analysis = self._complete_analysis(parsed, files_data, analysis_request, "lm_studio")
                repair = self._repair_with_provider("lm_studio", local_result)
                if repair and not lm_analysis:
                    parsed = self._parse_ai_json(repair, files_data, "lm_studio")
                    if parsed:
                        lm_analysis = self._complete_analysis(parsed, files_data, analysis_request, "lm_studio")
                if not lm_analysis:
                    lm_error = f"LM Studio returned invalid JSON. Chunked attempt: {chunked_error}"
                    provider_errors.append(lm_error)
            elif not lm_analysis:
                lm_error = f"LM Studio failed: {local_error}. Chunked attempt: {chunked_error}"
                provider_errors.append(lm_error)
        else:
            lm_error = (
                f"LM Studio unavailable: start LM Studio, load {self.model_name}, and enable the local server at http://localhost:1234/v1."
            )
            provider_errors.append(lm_error)

        fallback_analysis = None
        if not gemini_analysis and not lm_analysis:
            fallback_analysis = self._heuristic_analysis(files_data, analysis_request, provider_errors)

        final = self._combine_ai_responses(
            gemini_analysis=gemini_analysis,
            lm_analysis=lm_analysis,
            fallback_analysis=fallback_analysis,
            files_data=files_data,
            analysis_request=analysis_request,
            gemini_error=gemini_error,
            lm_error=lm_error,
        )
        return final

    def _resolve_gemini_model(self) -> Tuple[Optional[str], Optional[str]]:
        if self._resolved_gemini_model:
            return self._resolved_gemini_model, None

        requested = self.gemini_model
        if requested and requested.lower() != "auto":
            self._resolved_gemini_model = requested.replace("models/", "")
            return self._resolved_gemini_model, None

        models, error = self._list_gemini_models()
        if error:
            return None, error
        if not models:
            return None, "no Gemini models supporting generateContent were found for this API key"

        self._resolved_gemini_model = models[0]
        return self._resolved_gemini_model, None

    def _list_gemini_models(self) -> Tuple[List[str], Optional[str]]:
        if self._available_gemini_models is not None:
            return self._available_gemini_models, None

        try:
            response = requests.get(
                f"{self.gemini_api_base}/models",
                params={"key": self.gemini_api_key},
                timeout=30,
            )
            if response.status_code != 200:
                return [], f"could not list Gemini models: HTTP {response.status_code}: {response.text[:300]}"

            models = response.json().get("models", [])
            usable = []
            for model in models:
                methods = model.get("supportedGenerationMethods", [])
                name = model.get("name", "").replace("models/", "")
                if name and "generateContent" in methods:
                    usable.append(name)

            if not usable:
                return [], None

            preferred = (
                "gemini-2.5-flash",
                "gemini-2.5-pro",
                "gemini-2.0-flash",
                "gemini-2.0-flash-lite",
                "gemini-flash-latest",
                "gemini-pro-latest",
            )
            ordered = []
            for candidate in preferred:
                if candidate in usable:
                    ordered.append(candidate)

            for name in usable:
                if name not in ordered and "flash" in name.lower():
                    ordered.append(name)

            for name in usable:
                if name not in ordered:
                    ordered.append(name)

            self._available_gemini_models = ordered
            return ordered, None
        except requests.RequestException as exc:
            return [], f"could not list Gemini models: {exc}"

    def _gemini_model_candidates(self) -> Tuple[List[str], Optional[str]]:
        listed_models, list_error = self._list_gemini_models()
        requested = self.gemini_model.replace("models/", "")
        if requested and requested.lower() != "auto":
            return [requested] + [model for model in listed_models if model != requested], None
        return listed_models, list_error

    def _call_gemini(self, prompt: str) -> Tuple[Optional[str], Optional[str]]:
        try:
            models, model_error = self._gemini_model_candidates()
            if not models:
                return None, model_error or "no Gemini model available"

            errors = []
            for model in models[:6]:
                response = requests.post(
                    f"{self.gemini_api_base}/models/{model}:generateContent",
                    params={"key": self.gemini_api_key},
                    json={
                        "contents": [{"parts": [{"text": prompt}]}],
                        "generationConfig": {
                            "temperature": self.temperature,
                            "maxOutputTokens": self.max_tokens,
                            "responseMimeType": "application/json",
                        },
                    },
                    timeout=120,
                )
                if response.status_code != 200:
                    errors.append(f"{model}: HTTP {response.status_code}: {response.text[:180]}")
                    if response.status_code in {400, 404, 429, 500, 503}:
                        continue
                    return None, errors[-1]

                data = response.json()
                parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
                text = "".join(part.get("text", "") for part in parts).strip()
                if text:
                    self._resolved_gemini_model = model
                    return text, None
                errors.append(f"{model}: empty response")

            return None, "; ".join(errors) if errors else "empty Gemini response"
        except requests.RequestException as exc:
            return None, str(exc)
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            return None, f"unexpected Gemini response: {exc}"

    def _call_lm_studio(self, prompt: str) -> Tuple[Optional[str], Optional[str]]:
        try:
            response = requests.post(
                f"{self.local_llm_url}/v1/chat/completions",
                json={
                    "model": self.model_name,
                    "messages": [
                        {
                            "role": "system",
                            "content": "You are a precise code review assistant. Return only valid JSON.",
                        },
                        {"role": "user", "content": prompt},
                    ],
                    "temperature": self.temperature,
                    "max_tokens": self.local_max_tokens,
                    "stream": False,
                },
                headers={"Content-Type": "application/json"},
                timeout=180,
            )
            if response.status_code != 200:
                return None, f"HTTP {response.status_code}: {response.text[:300]}"
            data = response.json()
            text = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
            return text or None, None if text else "empty response"
        except requests.RequestException as exc:
            return None, str(exc)
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            return None, f"unexpected LM Studio response: {exc}"

    def _analyze_with_lm_studio_chunks(
        self,
        files_data: List[Dict],
        analysis_request: Dict,
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        chunks = self._make_review_chunks(files_data)
        if not chunks:
            return None, "no chunks created"

        chunk_reviews = []
        chunk_errors = []

        for index, chunk in enumerate(chunks[: self.max_chunks], 1):
            prompt = self._build_chunk_prompt(chunk, analysis_request, index, len(chunks))
            response, error = self._call_lm_studio(prompt)
            if not response:
                chunk_errors.append(f"chunk {index}: {error}")
                chunk_reviews.append(self._static_chunk_review(chunk, analysis_request, f"LM Studio error: {error}"))
                continue

            parsed = self._parse_chunk_json(response)
            if parsed:
                chunk_reviews.append(parsed)
            else:
                chunk_errors.append(f"chunk {index}: invalid JSON")
                chunk_reviews.append(self._static_chunk_review(chunk, analysis_request, response[:900]))

        if not chunk_reviews:
            return None, "; ".join(chunk_errors) or "no chunk reviews"

        merge_prompt = self._build_merge_prompt(chunk_reviews, analysis_request, files_data)
        merged_response, merge_error = self._call_lm_studio(merge_prompt)
        if merged_response:
            parsed = self._parse_ai_json(merged_response, files_data, "lm_studio_chunked")
            if parsed:
                parsed["chunk_statistics"] = {
                    "chunks_reviewed": len(chunk_reviews),
                    "chunk_char_budget": self.chunk_char_budget,
                    "chunk_errors": chunk_errors[:8],
                }
                return parsed, None

        synthesized = self._synthesize_from_chunk_reviews(chunk_reviews, files_data, analysis_request, chunk_errors)
        if synthesized:
            return synthesized, merge_error or "merge returned invalid JSON; synthesized from chunk reviews"

        return None, merge_error or "; ".join(chunk_errors) or "chunk analysis failed"

    def _make_review_chunks(self, files_data: List[Dict]) -> List[Dict[str, Any]]:
        priority_terms = (
            "main", "app", "index", "server", "api", "route", "component", "page",
            "config", "package", "readme", "schema", "model", "service", "controller",
        )
        sorted_files = sorted(
            files_data,
            key=lambda file: (
                not any(term in file.get("path", "").lower() for term in priority_terms),
                len(file.get("path", "")),
            ),
        )

        chunks = []
        current_files = []
        current_size = 0

        for file in sorted_files:
            content = file.get("content", "")
            path = file.get("path", "unknown")
            if not content.strip():
                continue

            slices = self._split_text(content, max(700, self.chunk_char_budget - 500))
            for part_index, part in enumerate(slices, 1):
                entry = {
                    "path": path,
                    "extension": file.get("extension", ""),
                    "size": file.get("size", len(content)),
                    "part": part_index,
                    "parts": len(slices),
                    "content": part,
                }
                entry_size = len(part) + len(path) + 160
                if current_files and current_size + entry_size > self.chunk_char_budget:
                    chunks.append({"files": current_files, "char_size": current_size})
                    current_files = []
                    current_size = 0
                    if len(chunks) >= self.max_chunks:
                        return chunks

                current_files.append(entry)
                current_size += entry_size

        if current_files and len(chunks) < self.max_chunks:
            chunks.append({"files": current_files, "char_size": current_size})

        return chunks

    def _split_text(self, text: str, max_chars: int) -> List[str]:
        if len(text) <= max_chars:
            return [text]

        lines = text.splitlines()
        parts = []
        current = []
        current_size = 0
        for line in lines:
            line_size = len(line) + 1
            if current and current_size + line_size > max_chars:
                parts.append("\n".join(current))
                current = []
                current_size = 0
            if line_size > max_chars:
                for index in range(0, len(line), max_chars):
                    parts.append(line[index : index + max_chars])
            else:
                current.append(line)
                current_size += line_size

        if current:
            parts.append("\n".join(current))

        return parts[:4]

    def _build_chunk_prompt(self, chunk: Dict[str, Any], analysis_request: Dict, index: int, total: int) -> str:
        file_blocks = []
        for file in chunk["files"]:
            file_blocks.append(
                f"FILE: {file['path']} part {file['part']}/{file['parts']}\n"
                f"EXT: {file['extension'] or 'none'}\n"
                f"CONTENT:\n{file['content']}"
            )

        return f"""You are reviewing one small chunk of a code project.
Return ONLY valid compact JSON. No markdown.

Project topic: {analysis_request.get('project_topic') or 'Not specified'}
Problem statement: {analysis_request.get('problem_statement') or 'Not specified'}
Custom requirements: {json.dumps(analysis_request.get('custom_requirements') or [], ensure_ascii=True)}

Chunk {index} of {total}:
{chr(10).join(file_blocks)}

JSON shape:
{{
  "files_reviewed": ["path"],
  "requirements_evidence": [
    {{"requirement_hint": "short requirement", "status": "Implemented|Partial|Missing", "location": "file path", "notes": "short evidence"}}
  ],
  "good_features": [
    {{"feature": "short feature", "location": "file path", "why_good": "short reason"}}
  ],
  "issues": [
    {{"issue": "short issue", "location": "file path", "problem": "short problem", "suggestion": "short fix", "priority": "High|Medium|Low"}}
  ],
  "summary": "one sentence"
}}"""

    def _parse_chunk_json(self, response: str) -> Optional[Dict[str, Any]]:
        for candidate in self._json_candidates(response):
            try:
                parsed = json.loads(self._clean_json(candidate))
                if isinstance(parsed, dict):
                    parsed.setdefault("files_reviewed", [])
                    parsed.setdefault("requirements_evidence", [])
                    parsed.setdefault("good_features", [])
                    parsed.setdefault("issues", [])
                    parsed.setdefault("summary", "")
                    return parsed
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
        return None

    def _static_chunk_review(
        self,
        chunk: Dict[str, Any],
        analysis_request: Dict,
        note: str = "",
    ) -> Dict[str, Any]:
        files = [
            {
                "path": item["path"],
                "content": item["content"],
                "size": len(item["content"]),
                "extension": item.get("extension", ""),
            }
            for item in chunk.get("files", [])
        ]
        requirements = self._extract_requirements(analysis_request)
        evidence = []
        for requirement in requirements[:8]:
            keywords = self._keywords(requirement)
            location = self._find_location(files, keywords)
            status = "Partial" if location != "Not found" else "Missing"
            evidence.append(
                {
                    "requirement_hint": requirement,
                    "status": status,
                    "location": location,
                    "notes": note[:180] or "Static chunk scan.",
                }
            )
        return {
            "files_reviewed": [file["path"] for file in files],
            "requirements_evidence": evidence,
            "good_features": self._static_good_features(files),
            "issues": self._static_quality_issues(files),
            "summary": "Static chunk scan completed.",
        }

    def _build_merge_prompt(
        self,
        chunk_reviews: List[Dict[str, Any]],
        analysis_request: Dict,
        files_data: List[Dict],
    ) -> str:
        compact_reviews = []
        for review in chunk_reviews[: self.max_chunks]:
            compact_reviews.append(
                {
                    "files_reviewed": review.get("files_reviewed", [])[:8],
                    "requirements_evidence": review.get("requirements_evidence", [])[:8],
                    "good_features": review.get("good_features", [])[:4],
                    "issues": review.get("issues", [])[:4],
                    "summary": review.get("summary", "")[:220],
                }
            )

        return f"""Merge these chunk code reviews into one final project review.
Return ONLY valid JSON matching the schema exactly.

Project topic: {analysis_request.get('project_topic') or 'Not specified'}
Problem statement: {analysis_request.get('problem_statement') or 'Not specified'}
Custom requirements: {json.dumps(analysis_request.get('custom_requirements') or [], ensure_ascii=True)}
Readable file count: {len(files_data)}

Chunk reviews:
{json.dumps(compact_reviews, ensure_ascii=True)[: self.local_prompt_char_budget]}

Final JSON schema:
{{
  "executive_summary": {{
    "what_user_built": "Description based on code review",
    "what_was_expected": "Requirements from problem statement",
    "match_percentage": 65,
    "overall_verdict": "Good"
  }},
  "requirements_checklist": [
    {{"requirement": "requirement", "status": "Implemented", "location": "file path", "quality": "Good", "notes": "evidence"}}
  ],
  "good_features": [
    {{"feature": "feature", "location": "file path", "why_good": "reason"}}
  ],
  "improvements_needed": [
    {{"missing_requirement": "requirement", "suggestion": "fix", "file_to_add": "path", "code_example": "code", "priority": "High", "effort_hours": 3}}
  ],
  "code_quality_issues": [
    {{"issue": "issue", "location": "path", "problem": "problem", "suggestion": "fix", "priority": "High"}}
  ],
  "final_score": {{"total": 68, "grade": "C+", "summary": "summary"}}
}}"""

    def _synthesize_from_chunk_reviews(
        self,
        chunk_reviews: List[Dict[str, Any]],
        files_data: List[Dict],
        analysis_request: Dict,
        chunk_errors: List[str],
    ) -> Dict[str, Any]:
        requirements = self._extract_requirements(analysis_request)
        checklist = []

        for requirement in requirements:
            related = []
            requirement_key = requirement.lower()
            requirement_words = set(self._keywords(requirement))
            for review in chunk_reviews:
                for item in review.get("requirements_evidence", []):
                    hint = str(item.get("requirement_hint", "")).lower()
                    hint_words = set(self._keywords(hint))
                    if requirement_key in hint or hint in requirement_key or requirement_words.intersection(hint_words):
                        related.append(item)

            status = "Missing"
            if any(item.get("status") == "Implemented" for item in related):
                status = "Implemented"
            elif any(item.get("status") == "Partial" for item in related):
                status = "Partial"

            location = next((item.get("location") for item in related if item.get("location") and item.get("location") != "Not found"), "Not found")
            notes = next((item.get("notes") for item in related if item.get("notes")), "No direct evidence found in chunk reviews.")
            checklist.append(
                {
                    "requirement": requirement,
                    "status": status,
                    "location": location,
                    "quality": "Good" if status == "Implemented" else ("Partial" if status == "Partial" else "N/A"),
                    "notes": notes,
                }
            )

        good_features = []
        issues = []
        seen_features = set()
        seen_issues = set()
        for review in chunk_reviews:
            for feature in review.get("good_features", []):
                key = (feature.get("feature", ""), feature.get("location", ""))
                if key not in seen_features:
                    seen_features.add(key)
                    good_features.append(feature)
            for issue in review.get("issues", []):
                key = (issue.get("issue", ""), issue.get("location", ""))
                if key not in seen_issues:
                    seen_issues.add(key)
                    issues.append(issue)

        match_percentage = self._calculate_match_percentage(checklist) or 0
        missing_or_partial = [item for item in checklist if item["status"] != "Implemented"]
        improvements = [
            {
                "missing_requirement": item["requirement"],
                "suggestion": f"Implement or complete this requirement and add evidence in code: {item['requirement']}",
                "file_to_add": "Relevant source file",
                "code_example": "// Add concrete implementation here and connect it to the existing UI/API flow.",
                "priority": "High" if item["status"] == "Missing" else "Medium",
                "effort_hours": 4 if item["status"] == "Missing" else 2,
            }
            for item in missing_or_partial[:6]
        ]

        return {
            "executive_summary": {
                "what_user_built": self._describe_project(files_data),
                "what_was_expected": analysis_request.get("problem_statement") or "User supplied requirements.",
                "match_percentage": match_percentage,
                "overall_verdict": "Good" if match_percentage >= 70 else "Needs Improvement",
            },
            "requirements_checklist": checklist,
            "good_features": good_features[:8],
            "improvements_needed": improvements,
            "code_quality_issues": issues[:8],
            "final_score": {
                "total": match_percentage,
                "grade": self._grade_for_score(match_percentage),
                "summary": "Chunked LM Studio analysis was synthesized from small file reviews. "
                f"Chunks reviewed: {len(chunk_reviews)}. Chunk errors: {len(chunk_errors)}.",
            },
            "file_statistics": self._file_statistics(files_data),
            "ai_provider": "lm_studio_chunked_synthesized",
            "chunk_statistics": {
                "chunks_reviewed": len(chunk_reviews),
                "chunk_char_budget": self.chunk_char_budget,
                "chunk_errors": chunk_errors[:8],
            },
        }

    def _repair_with_provider(self, provider: str, bad_json: str) -> Optional[str]:
        repair_prompt = (
            "Repair this response into ONLY valid JSON matching the requested schema. "
            "Do not add markdown or explanation.\n\n"
            f"{bad_json[:12000]}"
        )
        if provider == "gemini" and self.gemini_api_key:
            return self._call_gemini(repair_prompt)[0]
        if provider == "lm_studio" and self.lm_studio_available:
            return self._call_lm_studio(repair_prompt)[0]
        return None

    def _build_prompt(self, files_data: List[Dict], analysis_request: Dict, compact: bool = False) -> str:
        context = self._prepare_file_context(files_data, compact=compact)
        project_topic = analysis_request.get("project_topic") or "Not specified"
        problem_statement = analysis_request.get("problem_statement") or "Not specified"
        custom_requirements = analysis_request.get("custom_requirements") or []
        mode_note = (
            "Compact local-model mode: prioritize requirement matching, evidence, and the most important code examples."
            if compact
            else "Full cloud-model mode: read all included file excerpts carefully."
        )

        return f"""Analyze the submitted project against the problem statement.

You MUST:
- Read every file excerpt included below.
- Extract each explicit requirement from the problem statement and custom requirements.
- For each requirement, decide whether the code implements it.
- Use status exactly as "Implemented", "Partial", or "Missing".
- Provide file locations as evidence. If not found, use "Not found".
- List good features with concrete reasons.
- Generate specific improvements with code examples.
- Calculate match_percentage as requirements met / total requirements, counting Partial as 0.5.
- Return ONLY valid JSON. No markdown, no prose outside JSON.

MODE:
{mode_note}

PROJECT TOPIC:
{project_topic}

PROBLEM STATEMENT:
{problem_statement}

CUSTOM REQUIREMENTS:
{json.dumps(custom_requirements, ensure_ascii=True)}

PROJECT FILES:
{context}

Return this exact JSON shape:
{{
  "executive_summary": {{
    "what_user_built": "Description based on code review",
    "what_was_expected": "Requirements from problem statement",
    "match_percentage": 65,
    "overall_verdict": "Good"
  }},
  "requirements_checklist": [
    {{
      "requirement": "User authentication system",
      "status": "Implemented",
      "location": "src/auth/login.tsx line 23-45",
      "quality": "Good",
      "notes": "Uses JWT tokens"
    }}
  ],
  "good_features": [
    {{
      "feature": "Responsive UI design",
      "location": "styles/main.css, components/*.tsx",
      "why_good": "Uses flexbox, grid, and media queries effectively"
    }}
  ],
  "improvements_needed": [
    {{
      "missing_requirement": "AI API integration",
      "suggestion": "Create a service to call Gemini API",
      "file_to_add": "src/services/ai-service.ts",
      "code_example": "const callGemini = async (prompt) => {{ return fetch('/api/gemini', {{ method: 'POST' }}); }}",
      "priority": "High",
      "effort_hours": 3
    }}
  ],
  "code_quality_issues": [
    {{
      "issue": "Hardcoded API keys",
      "location": "config.js line 5",
      "problem": "Security risk",
      "suggestion": "Use environment variables",
      "priority": "High"
    }}
  ],
  "final_score": {{
    "total": 68,
    "grade": "C+",
    "summary": "Good foundation but missing core AI logic."
  }}
}}"""

    def _prepare_file_context(self, files_data: List[Dict], compact: bool = False) -> str:
        priority_terms = (
            "main",
            "app",
            "index",
            "server",
            "api",
            "route",
            "component",
            "page",
            "config",
            "package",
            "readme",
        )
        sorted_files = sorted(
            files_data,
            key=lambda file: (
                not any(term in file.get("path", "").lower() for term in priority_terms),
                len(file.get("path", "")),
            ),
        )
        selected = sorted_files[:15]
        per_file_limit = 400 if compact else 2000
        total_budget = self.local_prompt_char_budget if compact else 40000
        parts = [f"Total readable files discovered: {len(files_data)}"]
        parts.append(f"Files sent for detailed review: {len(selected)}")
        parts.append("File tree:")
        for file in sorted_files[:80]:
            parts.append(f"- {file.get('path', 'unknown')} ({file.get('extension', '') or 'none'}, {file.get('size', 0)} chars)")

        for index, file in enumerate(selected, 1):
            remaining_budget = total_budget - len("\n".join(parts))
            if remaining_budget <= 800:
                break
            content_limit = min(per_file_limit, max(250, remaining_budget // max(1, len(selected) - index + 1)))
            content = file.get("content", "")[:content_limit]
            section = (
                "\n"
                f"FILE {index}: {file.get('path', 'unknown')}\n"
                f"Extension: {file.get('extension', '') or 'none'}\n"
                f"Size: {file.get('size', len(content))} chars\n"
                "CONTENT:\n"
                f"{content}"
            )
            if len(file.get("content", "")) > len(content):
                section += "\n... truncated ..."
            parts.append(section)

        return "\n".join(parts)

    def _parse_ai_json(self, response: str, files_data: List[Dict], provider: str) -> Optional[Dict]:
        candidates = self._json_candidates(response)
        for candidate in candidates:
            try:
                parsed = json.loads(self._clean_json(candidate))
                normalized = self._normalize_response(parsed, files_data, provider)
                return normalized
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
        return None

    def _json_candidates(self, response: str) -> List[str]:
        cleaned = response.strip()
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s*```$", "", cleaned)
        candidates = [cleaned]

        start = cleaned.find("{")
        if start == -1:
            return candidates

        depth = 0
        in_string = False
        escape = False
        for index in range(start, len(cleaned)):
            char = cleaned[index]
            if escape:
                escape = False
                continue
            if char == "\\":
                escape = True
                continue
            if char == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    candidates.insert(0, cleaned[start : index + 1])
                    break
        return candidates

    def _clean_json(self, json_str: str) -> str:
        json_str = re.sub(r"//.*?(?=\n|$)", "", json_str)
        json_str = re.sub(r"/\*.*?\*/", "", json_str, flags=re.DOTALL)
        json_str = re.sub(r",\s*([}\]])", r"\1", json_str)
        json_str = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", json_str)
        return json_str.strip()

    def _normalize_response(self, result: Dict, files_data: List[Dict], provider: str) -> Dict:
        defaults = self._empty_result()

        for key, value in defaults.items():
            result.setdefault(key, value)

        result["executive_summary"] = {
            **defaults["executive_summary"],
            **(result.get("executive_summary") or {}),
        }
        result["final_score"] = {
            **defaults["final_score"],
            **(result.get("final_score") or {}),
        }

        checklist = result.get("requirements_checklist")
        result["requirements_checklist"] = checklist if isinstance(checklist, list) else []
        for item in result["requirements_checklist"]:
            if isinstance(item, dict):
                status = item.get("status", "Missing")
                item["status"] = status if status in {"Implemented", "Partial", "Missing"} else "Partial"

        match_percentage = self._calculate_match_percentage(result["requirements_checklist"])
        if match_percentage is not None:
            result["executive_summary"]["match_percentage"] = match_percentage

        result["good_features"] = result["good_features"] if isinstance(result.get("good_features"), list) else []
        result["improvements_needed"] = (
            result["improvements_needed"] if isinstance(result.get("improvements_needed"), list) else []
        )
        result["code_quality_issues"] = (
            result["code_quality_issues"] if isinstance(result.get("code_quality_issues"), list) else []
        )

        score = result["final_score"].get("total")
        if not isinstance(score, int):
            score = int(result["executive_summary"].get("match_percentage") or 0)
            result["final_score"]["total"] = score
        result["final_score"]["grade"] = result["final_score"].get("grade") or self._grade_for_score(score)

        result["file_statistics"] = self._file_statistics(files_data)
        result["ai_provider"] = provider
        return result

    def _complete_analysis(
        self,
        result: Dict[str, Any],
        files_data: List[Dict],
        analysis_request: Dict,
        provider: str,
    ) -> Dict[str, Any]:
        result = self._normalize_response(result, files_data, provider)
        expected_text = self._expected_text(analysis_request)
        static_result = self._heuristic_analysis(files_data, analysis_request, [])
        required_items = self._extract_requirements(analysis_request)

        summary = result["executive_summary"]
        if not self._useful_text(summary.get("what_user_built")):
            summary["what_user_built"] = self._describe_project(files_data)
        if not self._useful_text(summary.get("what_was_expected")):
            summary["what_was_expected"] = expected_text

        checklist = result.get("requirements_checklist") or []
        if not checklist:
            checklist = static_result.get("requirements_checklist", [])
        else:
            checklist = self._ensure_required_items(checklist, static_result.get("requirements_checklist", []), required_items)

        result["requirements_checklist"] = checklist
        match_percentage = self._calculate_match_percentage(checklist)
        if match_percentage is None:
            match_percentage = self._score_from_result(result)
        summary["match_percentage"] = match_percentage
        summary["overall_verdict"] = self._verdict_for_score(match_percentage)

        if not result.get("good_features"):
            result["good_features"] = static_result.get("good_features", [])
        if not result.get("code_quality_issues"):
            result["code_quality_issues"] = static_result.get("code_quality_issues", [])
        if not result.get("improvements_needed"):
            result["improvements_needed"] = self._default_improvements(checklist)

        result["future_improvements"] = result["improvements_needed"]
        result["final_score"]["total"] = match_percentage
        result["final_score"]["grade"] = self._grade_for_score(match_percentage)
        if not self._useful_text(result["final_score"].get("summary")):
            result["final_score"]["summary"] = self._summary_for_score(match_percentage, provider)

        result["file_statistics"] = self._file_statistics(files_data)
        result["ai_provider"] = provider
        return result

    def _combine_ai_responses(
        self,
        gemini_analysis: Optional[Dict[str, Any]],
        lm_analysis: Optional[Dict[str, Any]],
        fallback_analysis: Optional[Dict[str, Any]],
        files_data: List[Dict],
        analysis_request: Dict,
        gemini_error: Optional[str],
        lm_error: Optional[str],
    ) -> Dict[str, Any]:
        completed_fallback = (
            self._complete_analysis(fallback_analysis, files_data, analysis_request, "static_fallback")
            if fallback_analysis
            else None
        )
        available = [item for item in [gemini_analysis, lm_analysis] if item]

        if len(available) >= 2:
            final = self._consensus_analysis(gemini_analysis, lm_analysis, files_data, analysis_request)
        elif gemini_analysis:
            final = dict(gemini_analysis)
        elif lm_analysis:
            final = dict(lm_analysis)
        else:
            final = dict(completed_fallback)

        final["ai_responses"] = {
            "gemini": self._provider_payload("Gemini API", gemini_analysis, gemini_error),
            "lm_studio": self._provider_payload("LM Studio", lm_analysis, lm_error),
        }
        final["analysis_mode"] = "dual_ai" if gemini_analysis and lm_analysis else final.get("ai_provider", "static_fallback")
        final["file_statistics"] = self._file_statistics(files_data)
        return final

    def _consensus_analysis(
        self,
        gemini_analysis: Dict[str, Any],
        lm_analysis: Dict[str, Any],
        files_data: List[Dict],
        analysis_request: Dict,
    ) -> Dict[str, Any]:
        requirements = self._extract_requirements(analysis_request)
        gemini_items = gemini_analysis.get("requirements_checklist", [])
        lm_items = lm_analysis.get("requirements_checklist", [])
        checklist = []

        for requirement in requirements:
            related = self._related_items(requirement, gemini_items + lm_items)
            score = self._average_status_score(related)
            if score >= 0.75:
                status = "Implemented"
            elif score >= 0.25:
                status = "Partial"
            else:
                status = "Missing"
            location = self._first_useful([item.get("location") for item in related], "Not found")
            notes = self._first_useful([item.get("notes") for item in related], "Consensus review found limited direct evidence.")
            checklist.append(
                {
                    "requirement": requirement,
                    "status": status,
                    "location": location,
                    "quality": "Good" if status == "Implemented" else ("Partial" if status == "Partial" else "N/A"),
                    "notes": notes,
                }
            )

        if not checklist:
            checklist = gemini_items or lm_items

        score = self._calculate_match_percentage(checklist) or max(
            self._score_from_result(gemini_analysis),
            self._score_from_result(lm_analysis),
        )
        improvements = self._dedupe_dicts(
            (gemini_analysis.get("improvements_needed") or []) + (lm_analysis.get("improvements_needed") or []),
            ("missing_requirement", "suggestion"),
        )
        if not improvements:
            improvements = self._default_improvements(checklist)

        result = {
            "executive_summary": {
                "what_user_built": self._first_useful(
                    [
                        gemini_analysis.get("executive_summary", {}).get("what_user_built"),
                        lm_analysis.get("executive_summary", {}).get("what_user_built"),
                    ],
                    self._describe_project(files_data),
                ),
                "what_was_expected": self._expected_text(analysis_request),
                "match_percentage": score,
                "overall_verdict": self._verdict_for_score(score),
            },
            "requirements_checklist": checklist,
            "good_features": self._dedupe_dicts(
                (gemini_analysis.get("good_features") or []) + (lm_analysis.get("good_features") or []),
                ("feature", "location"),
            )[:10],
            "improvements_needed": improvements[:10],
            "future_improvements": improvements[:10],
            "code_quality_issues": self._dedupe_dicts(
                (gemini_analysis.get("code_quality_issues") or []) + (lm_analysis.get("code_quality_issues") or []),
                ("issue", "location"),
            )[:10],
            "final_score": {
                "total": score,
                "grade": self._grade_for_score(score),
                "summary": "Combined review from Gemini API and LM Studio. The score uses a consensus of both AI responses.",
            },
            "file_statistics": self._file_statistics(files_data),
            "ai_provider": "gemini_plus_lm_studio",
        }
        return result

    def _provider_payload(
        self,
        label: str,
        analysis: Optional[Dict[str, Any]],
        error: Optional[str],
    ) -> Dict[str, Any]:
        if not analysis:
            return {
                "provider": label,
                "success": False,
                "error": error or "No response",
                "analysis": None,
            }
        return {
            "provider": label,
            "success": True,
            "error": None,
            "analysis": {
                "executive_summary": analysis.get("executive_summary", {}),
                "requirements_checklist": analysis.get("requirements_checklist", []),
                "good_features": analysis.get("good_features", []),
                "improvements_needed": analysis.get("improvements_needed", []),
                "future_improvements": analysis.get("future_improvements", analysis.get("improvements_needed", [])),
                "code_quality_issues": analysis.get("code_quality_issues", []),
                "final_score": analysis.get("final_score", {}),
                "ai_provider": analysis.get("ai_provider", ""),
            },
        }

    def _ensure_required_items(
        self,
        checklist: List[Dict[str, Any]],
        static_checklist: List[Dict[str, Any]],
        requirements: List[str],
    ) -> List[Dict[str, Any]]:
        completed = [item for item in checklist if isinstance(item, dict)]
        for requirement in requirements:
            if self._related_items(requirement, completed):
                continue
            replacement = self._related_items(requirement, static_checklist)
            if replacement:
                completed.append(replacement[0])
            else:
                completed.append(
                    {
                        "requirement": requirement,
                        "status": "Missing",
                        "location": "Not found",
                        "quality": "N/A",
                        "notes": "No evidence found for this requirement.",
                    }
                )
        return completed

    def _related_items(self, requirement: str, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        requirement_words = set(self._keywords(requirement))
        related = []
        for item in items:
            if not isinstance(item, dict):
                continue
            item_text = str(item.get("requirement") or item.get("requirement_hint") or "")
            item_words = set(self._keywords(item_text))
            if requirement.lower() in item_text.lower() or item_text.lower() in requirement.lower():
                related.append(item)
            elif requirement_words and item_words and requirement_words.intersection(item_words):
                related.append(item)
        return related

    def _average_status_score(self, items: List[Dict[str, Any]]) -> float:
        if not items:
            return 0.0
        values = []
        for item in items:
            status = item.get("status")
            if status == "Implemented":
                values.append(1.0)
            elif status == "Partial":
                values.append(0.5)
            else:
                values.append(0.0)
        return sum(values) / len(values)

    def _default_improvements(self, checklist: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        improvements = []
        for item in checklist:
            if item.get("status") == "Implemented":
                continue
            requirement = item.get("requirement", "Missing requirement")
            improvements.append(
                {
                    "missing_requirement": requirement,
                    "suggestion": f"Add a clear implementation for: {requirement}",
                    "file_to_add": "Relevant source file",
                    "code_example": "// Example\n// Add the missing feature, connect it to the existing flow, and add validation/tests.",
                    "priority": "High" if item.get("status") == "Missing" else "Medium",
                    "effort_hours": 4 if item.get("status") == "Missing" else 2,
                }
            )
        if improvements:
            return improvements
        return [
            {
                "missing_requirement": "Future polish",
                "suggestion": "Add automated tests, stronger error handling, and clearer documentation.",
                "file_to_add": "tests/ or docs/",
                "code_example": "// Example\n// Add unit tests for the main user flows and edge cases.",
                "priority": "Low",
                "effort_hours": 2,
            }
        ]

    def _expected_text(self, analysis_request: Dict) -> str:
        parts = []
        if analysis_request.get("project_topic"):
            parts.append(f"Project topic: {analysis_request['project_topic']}")
        if analysis_request.get("problem_statement"):
            parts.append(str(analysis_request["problem_statement"]))
        custom = analysis_request.get("custom_requirements") or []
        if custom:
            parts.append("Custom requirements: " + ", ".join(str(item) for item in custom))
        return " ".join(parts) if parts else "Requirements were not provided by the user."

    def _score_from_result(self, result: Dict[str, Any]) -> int:
        for value in [
            result.get("final_score", {}).get("total"),
            result.get("executive_summary", {}).get("match_percentage"),
        ]:
            try:
                return max(0, min(100, round(float(value))))
            except (TypeError, ValueError):
                continue
        return 0

    def _verdict_for_score(self, score: int) -> str:
        if score >= 75:
            return "Good"
        if score >= 40:
            return "Needs Improvement"
        return "Poor"

    def _summary_for_score(self, score: int, provider: str) -> str:
        if score >= 75:
            return f"{provider} found a strong match with the expected requirements."
        if score >= 40:
            return f"{provider} found a partial match. The project needs improvement in several areas."
        return f"{provider} found major missing requirements. Focus on the improvement list first."

    def _useful_text(self, value: Any) -> bool:
        text = str(value or "").strip().lower()
        return bool(text) and text not in {"n/a", "na", "none", "not available", "unknown"}

    def _first_useful(self, values: List[Any], fallback: str) -> str:
        for value in values:
            if self._useful_text(value):
                return str(value)
        return fallback

    def _dedupe_dicts(self, items: List[Dict[str, Any]], keys: Tuple[str, ...]) -> List[Dict[str, Any]]:
        result = []
        seen = set()
        for item in items:
            if not isinstance(item, dict):
                continue
            key = tuple(str(item.get(field, "")).lower() for field in keys)
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    def _calculate_match_percentage(self, checklist: List[Any]) -> Optional[int]:
        if not checklist:
            return None
        earned = 0.0
        total = 0
        for item in checklist:
            if not isinstance(item, dict):
                continue
            total += 1
            status = item.get("status")
            if status == "Implemented":
                earned += 1
            elif status == "Partial":
                earned += 0.5
        return round((earned / total) * 100) if total else None

    def _file_statistics(self, files_data: List[Dict]) -> Dict[str, Any]:
        file_types: Dict[str, int] = {}
        for file in files_data:
            ext = (file.get("extension") or "none").lower().lstrip(".") or "none"
            file_types[ext] = file_types.get(ext, 0) + 1
        return {
            "total_files": len(files_data),
            "file_types": file_types,
            "total_size_kb": round(sum(file.get("size", 0) for file in files_data) / 1024, 2),
            "reviewed_file_limit": 15,
            "reviewed_chars_per_file": 2000,
        }

    def _empty_result(self) -> Dict[str, Any]:
        return {
            "executive_summary": {
                "what_user_built": "",
                "what_was_expected": "",
                "match_percentage": 0,
                "overall_verdict": "Needs Improvement",
            },
            "requirements_checklist": [],
            "good_features": [],
            "improvements_needed": [],
            "code_quality_issues": [],
            "final_score": {
                "total": 0,
                "grade": "N/A",
                "summary": "",
            },
        }

    def _error_response(self, message: str, files_data: Optional[List[Dict]] = None) -> Dict[str, Any]:
        result = self._empty_result()
        result["executive_summary"]["what_user_built"] = "Analysis could not be completed."
        result["executive_summary"]["what_was_expected"] = "A working Gemini API key or LM Studio fallback."
        result["final_score"]["summary"] = message
        result["setup_instructions"] = {
            "gemini": "Set GEMINI_API_KEY. Leave GEMINI_MODEL unset or set GEMINI_MODEL=auto so the app can pick an available generateContent model.",
            "lm_studio": f"Open LM Studio, load {self.model_name}, start the local server, and keep LOCAL_PROMPT_CHAR_BUDGET at 3800 or lower for 4096-token 3B models.",
        }
        result["file_statistics"] = self._file_statistics(files_data or [])
        result["ai_provider"] = "none"
        return result

    def _heuristic_analysis(
        self,
        files_data: List[Dict],
        analysis_request: Dict,
        provider_errors: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        requirements = self._extract_requirements(analysis_request)
        all_content = "\n".join(file.get("content", "") for file in files_data).lower()
        checklist = []

        for requirement in requirements:
            keywords = self._keywords(requirement)
            matches = sum(1 for keyword in keywords if keyword in all_content)
            ratio = matches / max(1, len(keywords))
            if ratio >= 0.45:
                status = "Implemented"
                quality = "Needs Review"
            elif ratio >= 0.2:
                status = "Partial"
                quality = "Partial"
            else:
                status = "Missing"
                quality = "N/A"

            location = self._find_location(files_data, keywords) if status != "Missing" else "Not found"
            checklist.append(
                {
                    "requirement": requirement,
                    "status": status,
                    "location": location,
                    "quality": quality,
                    "notes": "Estimated by local static fallback because AI providers did not return usable JSON.",
                }
            )

        match_percentage = self._calculate_match_percentage(checklist) or 0
        code_quality_issues = self._static_quality_issues(files_data)
        good_features = self._static_good_features(files_data)
        missing = [item["requirement"] for item in checklist if item["status"] == "Missing"]
        partial = [item["requirement"] for item in checklist if item["status"] == "Partial"]

        improvements = []
        for requirement in (missing + partial)[:5]:
            improvements.append(
                {
                    "missing_requirement": requirement,
                    "suggestion": f"Add or complete code that directly satisfies: {requirement}",
                    "file_to_add": "Add to the most relevant existing module",
                    "code_example": "// Example\nfunction implementRequirement() {\n  // wire this requirement into the UI/API and add validation/tests\n}",
                    "priority": "High" if requirement in missing else "Medium",
                    "effort_hours": 2 if requirement in partial else 4,
                }
            )

        error_note = " ".join(provider_errors or [])
        result = {
            "executive_summary": {
                "what_user_built": self._describe_project(files_data),
                "what_was_expected": analysis_request.get("problem_statement") or "Requirements supplied by the user.",
                "match_percentage": match_percentage,
                "overall_verdict": "Good" if match_percentage >= 70 else "Needs Improvement",
            },
            "requirements_checklist": checklist,
            "good_features": good_features,
            "improvements_needed": improvements,
            "code_quality_issues": code_quality_issues,
            "final_score": {
                "total": match_percentage,
                "grade": self._grade_for_score(match_percentage),
                "summary": (
                    "Static fallback analysis completed because AI providers failed or returned invalid JSON. "
                    f"Provider details: {error_note}"
                ).strip(),
            },
            "file_statistics": self._file_statistics(files_data),
            "ai_provider": "static_fallback",
        }
        return result

    def _extract_requirements(self, analysis_request: Dict) -> List[str]:
        requirements = []
        problem = analysis_request.get("problem_statement") or ""
        custom = analysis_request.get("custom_requirements") or []

        for part in re.split(r"[\n.;]|(?:\s-\s)", problem):
            cleaned = part.strip(" -\t\r")
            if len(cleaned) >= 8:
                requirements.append(cleaned)

        for item in custom:
            cleaned = str(item).strip()
            if cleaned:
                requirements.append(cleaned)

        if not requirements:
            topic = analysis_request.get("project_topic") or "Submitted project"
            requirements.append(f"Implement the expected features for {topic}")

        deduped = []
        seen = set()
        for requirement in requirements:
            key = requirement.lower()
            if key not in seen:
                seen.add(key)
                deduped.append(requirement)
        return deduped[:12]

    def _keywords(self, text: str) -> List[str]:
        stop_words = {
            "the", "and", "for", "with", "that", "this", "from", "into", "your",
            "project", "build", "create", "make", "using", "should", "must",
        }
        words = re.findall(r"[a-zA-Z][a-zA-Z0-9_-]{2,}", text.lower())
        return [word for word in words if word not in stop_words][:10]

    def _find_location(self, files_data: List[Dict], keywords: List[str]) -> str:
        best_file = None
        best_score = 0
        for file in files_data:
            content = file.get("content", "").lower()
            score = sum(1 for keyword in keywords if keyword in content)
            if score > best_score:
                best_score = score
                best_file = file
        return best_file.get("path", "Not found") if best_file else "Not found"

    def _describe_project(self, files_data: List[Dict]) -> str:
        extensions = sorted({(file.get("extension") or "none").lstrip(".") for file in files_data})
        important = [file.get("path", "") for file in files_data[:5]]
        return f"Project with {len(files_data)} readable files using {', '.join(extensions[:8])}. Key files include: {', '.join(important)}."

    def _static_good_features(self, files_data: List[Dict]) -> List[Dict[str, str]]:
        features = []
        paths = [file.get("path", "") for file in files_data]
        extensions = {file.get("extension", "").lower() for file in files_data}
        if any(ext in extensions for ext in [".html", ".css", ".js", ".jsx", ".tsx"]):
            features.append(
                {
                    "feature": "Frontend structure present",
                    "location": ", ".join(paths[:4]),
                    "why_good": "The project includes browser-facing files that can implement the user interface.",
                }
            )
        if any("package.json" in path.lower() for path in paths):
            features.append(
                {
                    "feature": "JavaScript dependency manifest",
                    "location": "package.json",
                    "why_good": "A package manifest makes dependencies and scripts easier to reproduce.",
                }
            )
        if any("readme" in path.lower() for path in paths):
            features.append(
                {
                    "feature": "Project documentation",
                    "location": "README",
                    "why_good": "Documentation helps reviewers understand setup and purpose.",
                }
            )
        return features[:5]

    def _static_quality_issues(self, files_data: List[Dict]) -> List[Dict[str, str]]:
        issues = []
        secret_pattern = re.compile(r"(api[_-]?key|secret|token|password)\s*[:=]\s*['\"][^'\"]{8,}", re.IGNORECASE)
        for file in files_data:
            content = file.get("content", "")
            path = file.get("path", "unknown")
            if secret_pattern.search(content):
                issues.append(
                    {
                        "issue": "Possible hardcoded secret",
                        "location": path,
                        "problem": "Secrets in source code can leak credentials.",
                        "suggestion": "Move secrets into environment variables and keep them out of Git.",
                        "priority": "High",
                    }
                )
            if "todo" in content.lower() or "fixme" in content.lower():
                issues.append(
                    {
                        "issue": "Unresolved TODO/FIXME comments",
                        "location": path,
                        "problem": "Pending implementation notes may indicate incomplete behavior.",
                        "suggestion": "Resolve the TODOs or track them in project issues.",
                        "priority": "Medium",
                    }
                )
            if len(issues) >= 6:
                break
        return issues

    def _grade_for_score(self, score: int) -> str:
        if score >= 90:
            return "A"
        if score >= 80:
            return "B"
        if score >= 70:
            return "C+"
        if score >= 60:
            return "C"
        if score >= 50:
            return "D"
        return "F"
