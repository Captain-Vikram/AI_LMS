from git import Repo
import os
import shutil
from pathlib import Path
from typing import List, Dict

class GitHubUtils:
    def __init__(self, temp_dir: str = "./temp_repos"):
        self.temp_dir = temp_dir
        os.makedirs(temp_dir, exist_ok=True)
    
    async def clone_repository(self, repo_url: str, branch: str = "main") -> str:
        """Clone GitHub repository and return local path"""
        repo_name = repo_url.rstrip('/').split('/')[-1].replace('.git', '')
        local_path = os.path.join(self.temp_dir, repo_name)
        
        # Remove if exists
        if os.path.exists(local_path):
            shutil.rmtree(local_path)
        
        try:
            # Clone repository
            Repo.clone_from(repo_url, local_path, branch=branch, depth=1)
            return local_path
        except Exception as e:
            raise Exception(f"Failed to clone repository: {str(e)}")
    
    async def read_project_files(self, repo_path: str) -> List[Dict]:
        """Read all relevant project files"""
        files_data = []
        exclude_dirs = {'.git', '__pycache__', 'node_modules', 'dist', 'build', '.venv', 'env', '.next', 'coverage'}
        exclude_extensions = {
            '.pyc', '.pyo', '.so', '.dll', '.exe', '.jpg', '.jpeg', '.png', '.gif',
            '.webp', '.ico', '.mp4', '.mp3', '.wav', '.zip', '.tar', '.rar', '.7z',
            '.pdf', '.woff', '.woff2', '.ttf'
        }
        
        for root, dirs, files in os.walk(repo_path):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                file_path = os.path.join(root, file)
                extension = os.path.splitext(file)[1].lower()
                
                # Skip binary files
                if extension in exclude_extensions:
                    continue
                
                # Skip large files (>1MB)
                if os.path.getsize(file_path) > 1024 * 1024:
                    continue
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    relative_path = os.path.relpath(file_path, repo_path)
                    files_data.append({
                        'path': relative_path,
                        'content': content,
                        'size': len(content),
                        'extension': extension
                    })
                except Exception:
                    continue
        
        return files_data
    
    async def cleanup(self, repo_path: str):
        """Clean up temporary repository"""
        if os.path.exists(repo_path):
            shutil.rmtree(repo_path)
