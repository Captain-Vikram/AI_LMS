# 🚀 Project Analyzer - Setup & Run Guide

## Quick Start

### Step 1: Install Dependencies

```bash
# Navigate to backend directory
cd backend

# Install all required packages
pip install -r requirements.txt
```

**Required packages**:
- fastapi - Web framework
- uvicorn - ASGI server
- python-multipart - File upload support
- requests - HTTP client for LM Studio
- python-dotenv - Environment variables
- GitPython - Git repository cloning

---

### Step 2: Start LM Studio (Local AI)

1. **Download LM Studio** from: https://lmstudio.ai/

2. **Launch LM Studio** and:
   - Go to Models tab
   - Download a model: **DeepSeek Coder 1.3B** (recommended) or any other model
   - Click the model to load it into memory
   - You should see a running indicator

3. **Verify it's running**:
   - Open browser: `http://localhost:1234/v1/models`
   - You should see JSON with model info

---

### Step 3: Configure Backend (Optional)

The `.env` file is already configured:

```env
LOCAL_LLM_URL=http://localhost:1234
MODEL_NAME=deepseek-coder-1.3b-instruct
MODEL_TEMPERATURE=0.7
MODEL_MAX_TOKENS=2000
```

You can modify these if needed.

---

### Step 4: Start the Backend Server

```bash
# From project-analyzer/backend directory
python main.py
```

You should see output:
```
==================================================
🚀 Starting Project Analyzer with Local LLM
==================================================
📡 LM Studio Status: Connected
🔗 API Server: http://localhost:8000
📊 Status Check: http://localhost:8000/status
==================================================
INFO:     Uvicorn running on http://0.0.0.0:0.0.0.0:8000
```

---

### Step 5: Open the Frontend

1. **Open your browser**
2. **Navigate to**: `http://localhost:8000`
3. You should see the **Project Analyzer UI**

---

## 📊 Available Features

### 1. ZIP File Upload
- Drag & drop your project ZIP file
- System reads all project files
- AI analyzes code structure and quality
- Provides detailed feedback

### 2. GitHub Repository Analysis
- Paste GitHub repository URL
- Optionally specify branch (default: main)
- System clones and analyzes the repository
- Generates comprehensive report

### 3. Add Optional Context
- **Project Topic**: What is this project about?
- **Problem Statement**: What problem does it solve?
- **Custom Requirements**: Specific things to analyze

---

## 🧪 Testing

### Test the Status Endpoint
```bash
curl http://localhost:8000/status
```

Expected response:
```json
{
  "connected": true,
  "model": "deepseek-coder-1.3b-instruct",
  "url": "http://localhost:1234",
  "temperature": 0.7,
  "max_tokens": 2000
}
```

### Test Zip Upload
Create a test ZIP file with some code files and upload through the UI

### Test GitHub Analysis
Try a public repository like: `https://github.com/username/repository`

---

## 🐛 Troubleshooting

### Issue: "LM Studio not connected"
- **Solution**: Make sure LM Studio is running and a model is loaded
- Check: `http://localhost:1234/v1/models`

### Issue: "Address already in use"
- **Solution**: Port 8000 is already in use
- Kill process: `lsof -ti:8000 | xargs kill -9` (Unix)
- Or change port in `main.py`: `uvicorn.run(app, host="0.0.0.0", port=8001)`

### Issue: "No files found in ZIP"
- **Solution**: Make sure ZIP contains actual code files
- Empty folders won't be processed

### Issue: "Failed to clone repository"
- **Solution**: Check GitHub URL format
- Must be: `https://github.com/username/repository`
- Ensure repository is public or you have access

### Issue: Module not found errors
- **Solution**: Reinstall packages:
  ```bash
  pip install --upgrade -r requirements.txt
  ```

---

## 📈 How Analysis Works

1. **File Reading**
   - System scans project for readable files
   - Skips: `.git`, `node_modules`, `__pycache__`, binaries
   - Reads up to 10,000 characters per file

2. **Context Preparation**
   - Creates summary of project structure
   - Extracts first 3 files as context
   - Prepares prompt for AI model

3. **AI Analysis**
   - Sends context to LM Studio
   - Model identifies project purpose
   - Analyzes code quality
   - Identifies improvements

4. **Report Generation**
   - Scores match with problem statement (0-100%)
   - Lists good features
   - Provides improvement suggestions
   - Calculates code quality metrics

5. **Results Display**
   - Shows comprehensive report
   - Provides actionable suggestions
   - Allows JSON download

---

## 💾 Output Format

Analysis results include:

```json
{
  "project_topic_identification": {
    "identified_topic": "...",
    "main_technologies": [...],
    "project_complexity": "...",
    "estimated_completion_percentage": 75
  },
  "problem_statement_match_score": 75,
  "good_features": [...],
  "improvement_suggestions": [...],
  "code_quality_score": 78,
  "technical_debt_areas": [...],
  "recommendations": [...]
}
```

---

## 🎯 Next Steps

1. ✅ Install dependencies
2. ✅ Start LM Studio
3. ✅ Run backend server
4. ✅ Open frontend in browser
5. ✅ Upload a project or GitHub link
6. ✅ Review analysis results
7. ✅ Download report as JSON

Enjoy your AI-powered code analysis! 🚀
