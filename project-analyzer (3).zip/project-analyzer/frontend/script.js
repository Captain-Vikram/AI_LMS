let currentMode = 'zip';
let selectedFile = null;
let analysisData = null;
const API_BASE_URL = window.location.origin;

document.addEventListener('DOMContentLoaded', () => {
    setupDragAndDrop();
    checkStatus();
});

async function checkStatus() {
    const dot = document.querySelector('.status-dot');
    const txt = document.querySelector('.status-text');
    try {
        const response = await fetch(`${API_BASE_URL}/status`);
        if (!response.ok) throw new Error('status failed');
        const status = await response.json();
        dot.classList.toggle('connected', status.available);
        dot.classList.toggle('error', !status.available);

        const gemini = status.primary?.configured ? 'Gemini ready' : 'Gemini not configured';
        const local = status.fallback?.connected ? 'LM Studio ready' : 'LM Studio offline';
        txt.textContent = `${gemini} | ${local}`;
    } catch {
        dot.classList.add('error');
        txt.textContent = 'Server offline';
    }
}

function switchMode(mode) {
    currentMode = mode;
    document.getElementById('btn-zip').classList.toggle('active', mode === 'zip');
    document.getElementById('btn-github').classList.toggle('active', mode === 'github');
    document.getElementById('toggle-slider').classList.toggle('right', mode === 'github');
    document.getElementById('zip-mode').classList.toggle('active', mode === 'zip');
    document.getElementById('github-mode').classList.toggle('active', mode === 'github');
}

function toggleOptions() {
    document.getElementById('options-body').classList.toggle('open');
    document.getElementById('options-chevron').classList.toggle('rotated');
}

function setupDragAndDrop() {
    const area = document.getElementById('upload-area');
    const input = document.getElementById('zip-file');

    area.addEventListener('click', () => input.click());
    area.addEventListener('dragover', event => {
        event.preventDefault();
        area.classList.add('drag-over');
    });
    area.addEventListener('dragleave', () => area.classList.remove('drag-over'));
    area.addEventListener('drop', event => {
        event.preventDefault();
        area.classList.remove('drag-over');
        const file = event.dataTransfer.files[0];
        if (file && file.name.toLowerCase().endsWith('.zip')) {
            handleFileSelect(file);
        } else {
            showError('Please upload a ZIP file.');
        }
    });
    input.addEventListener('change', event => {
        const file = event.target.files[0];
        if (file) handleFileSelect(file);
    });
}

function handleFileSelect(file) {
    selectedFile = file;
    const info = document.getElementById('file-info');
    info.style.display = 'flex';
    info.innerHTML = `
        <span><i class="fas fa-file-archive"></i>${esc(file.name)}
        <span class="muted">(${(file.size / 1024).toFixed(1)} KB)</span></span>
        <button class="remove-file" onclick="clearFile()" aria-label="Remove file"><i class="fas fa-times"></i></button>
    `;
}

function clearFile() {
    selectedFile = null;
    document.getElementById('file-info').style.display = 'none';
    document.getElementById('zip-file').value = '';
}

async function analyzeProject() {
    const button = document.getElementById('analyze-btn');
    const content = document.getElementById('btn-content');
    const loader = document.getElementById('btn-loader');

    try {
        content.style.display = 'none';
        loader.style.display = 'flex';
        button.disabled = true;

        let result;
        if (currentMode === 'zip') {
            if (!selectedFile) throw new Error('Please select a ZIP file first.');
            result = await analyzeZip();
        } else {
            const url = document.getElementById('github-url').value.trim();
            if (!url) throw new Error('Please enter a GitHub repository URL.');
            result = await analyzeGitHub();
        }

        analysisData = result;
        displayResults(result);
    } catch (error) {
        showError(error.message || 'Analysis failed.');
    } finally {
        content.style.display = 'flex';
        loader.style.display = 'none';
        button.disabled = false;
    }
}

async function analyzeZip() {
    const formData = buildAnalysisFormData();
    formData.append('file', selectedFile);
    const response = await fetch(`${API_BASE_URL}/analyze/zip`, { method: 'POST', body: formData });
    return parseApiResponse(response);
}

async function analyzeGitHub() {
    const formData = buildAnalysisFormData();
    formData.append('repo_url', document.getElementById('github-url').value.trim());
    formData.append('branch', document.getElementById('github-branch').value.trim() || 'main');
    const response = await fetch(`${API_BASE_URL}/analyze/github`, { method: 'POST', body: formData });
    return parseApiResponse(response);
}

function buildAnalysisFormData() {
    const formData = new FormData();
    formData.append('project_topic', document.getElementById('project-topic').value.trim());
    formData.append('problem_statement', document.getElementById('problem-statement').value.trim());
    formData.append('custom_requirements', document.getElementById('custom-requirements').value.trim());
    return formData;
}

async function parseApiResponse(response) {
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(data.detail || `Server error: ${response.status}`);
    }
    return data;
}

function displayResults(data) {
    const section = document.getElementById('results');
    const container = document.getElementById('results-content');
    const summary = data.executive_summary || {};
    const finalScore = data.final_score || {};
    const stats = data.file_statistics || {};

    container.innerHTML = `
        ${renderScore(finalScore, summary, data.ai_provider)}
        ${renderSummary(summary)}
        ${renderDualAiResponses(data.ai_responses)}
        ${renderRequirements(data.requirements_checklist || [])}
        ${renderGoodFeatures(data.good_features || [])}
        ${renderImprovements(data.future_improvements || data.improvements_needed || [])}
        ${renderQualityIssues(data.code_quality_issues || [])}
        ${renderFileStats(stats)}
        ${renderSetupInstructions(data.setup_instructions)}
    `;

    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderScore(score, summary, provider) {
    const total = clampScore(score.total ?? summary.match_percentage ?? 0);
    const grade = score.grade || gradeForScore(total);
    return `
        <div class="result-card verdict-hero">
            <div class="score-ring" style="--score-pct:${total}%;--ring-color:${ringColor(total)}">
                <div><span class="score-value">${total}</span><span class="score-label">/ 100</span></div>
            </div>
            <div class="grade-badge ${gradeClass(grade)}">Grade: ${esc(grade)}</div>
            <p class="verdict-summary">${esc(score.summary || summary.overall_verdict || '')}</p>
            ${provider ? `<span class="provider-badge"><i class="fas fa-bolt"></i> ${esc(providerLabel(provider))}</span>` : ''}
        </div>
    `;
}

function renderSummary(summary) {
    return `
        <div class="result-card">
            <h3><i class="fas fa-file-alt"></i> Executive Summary</h3>
            <div class="summary-grid">
                <div>
                    <h4>What User Built</h4>
                    <p>${esc(summary.what_user_built || 'Not available')}</p>
                </div>
                <div>
                    <h4>What Was Expected</h4>
                    <p>${esc(summary.what_was_expected || 'Not available')}</p>
                </div>
            </div>
            <div class="summary-footer">
                <span class="assessment-badge ${verdictClass(summary.overall_verdict)}">${esc(summary.overall_verdict || 'Needs Improvement')}</span>
                <span class="match-pill">${clampScore(summary.match_percentage || 0)}% match</span>
            </div>
        </div>
    `;
}

function renderRequirements(items) {
    if (!items.length) return '';
    return `
        <div class="result-card">
            <h3><i class="fas fa-list-check"></i> Requirements Checklist</h3>
            <div class="checklist">
                ${items.map(item => `
                    <div class="requirement-item">
                        <div class="requirement-top">
                            <strong>${esc(item.requirement || '')}</strong>
                            <span class="status-badge ${statusClass(item.status)}">${esc(item.status || 'Missing')}</span>
                        </div>
                        <div class="requirement-meta">
                            <span><i class="fas fa-location-dot"></i> ${esc(item.location || 'Not found')}</span>
                            <span class="${qualityClass(item.quality)}">${esc(item.quality || 'N/A')}</span>
                        </div>
                        <p>${esc(item.notes || '')}</p>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderDualAiResponses(responses) {
    if (!responses) return '';
    const gemini = responses.gemini || {};
    const lmStudio = responses.lm_studio || {};
    return `
        <div class="result-card">
            <h3><i class="fas fa-code-compare"></i> Gemini vs LM Studio</h3>
            <div class="ai-compare-grid">
                ${renderProviderReport(gemini)}
                ${renderProviderReport(lmStudio)}
            </div>
        </div>
    `;
}

function renderProviderReport(response) {
    const analysis = response.analysis || {};
    const summary = analysis.executive_summary || {};
    const score = analysis.final_score || {};
    const total = clampScore(score.total ?? summary.match_percentage ?? 0);
    const checklist = analysis.requirements_checklist || [];
    const improvements = analysis.future_improvements || analysis.improvements_needed || [];

    if (!response.success) {
        return `
            <div class="ai-report-card failed">
                <div class="ai-report-top">
                    <h4>${esc(response.provider || 'AI Provider')}</h4>
                    <span class="status-badge status-no">Failed</span>
                </div>
                <p>${esc(response.error || 'No response')}</p>
            </div>
        `;
    }

    return `
        <div class="ai-report-card">
            <div class="ai-report-top">
                <h4>${esc(response.provider || 'AI Provider')}</h4>
                <span class="status-badge status-yes">Success</span>
            </div>
            <div class="ai-score-row">
                <span class="mini-grade ${gradeClass(score.grade || gradeForScore(total))}">${esc(score.grade || gradeForScore(total))}</span>
                <span>${total}% match</span>
            </div>
            <p><strong>Built:</strong> ${esc(summary.what_user_built || 'Not available')}</p>
            <p><strong>Expected:</strong> ${esc(summary.what_was_expected || 'Not available')}</p>
            <p><strong>Needs improvement:</strong> ${esc(summary.overall_verdict || 'Needs Improvement')}</p>
            ${checklist.length ? `<p><strong>Checklist:</strong> ${checklist.length} requirement checks</p>` : ''}
            ${improvements.length ? `<p><strong>Future improvements:</strong> ${improvements.slice(0, 2).map(item => esc(item.missing_requirement || item.suggestion || '')).join(', ')}</p>` : ''}
        </div>
    `;
}

function renderGoodFeatures(items) {
    if (!items.length) return '';
    return `
        <div class="result-card">
            <h3><i class="fas fa-circle-check"></i> Good Features</h3>
            <div class="card-grid">
                ${items.map(item => `
                    <div class="mini-card positive">
                        <h4>${esc(item.feature || '')}</h4>
                        <p class="mini-location">${esc(item.location || '')}</p>
                        <p>${esc(item.why_good || '')}</p>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderImprovements(items) {
    if (!items.length) return '';
    return `
        <div class="result-card">
            <h3><i class="fas fa-wrench"></i> Future Improvements</h3>
            ${items.map(item => `
                <div class="improvement-card">
                    <div class="improvement-header">
                        <span class="improvement-title">${esc(item.missing_requirement || 'Improvement')}</span>
                        <div class="improvement-meta">
                            <span class="priority-badge priority-${priorityClass(item.priority)}">${esc(item.priority || 'Medium')}</span>
                            <span class="effort-badge"><i class="fas fa-clock"></i> ${esc(String(item.effort_hours ?? ''))}h</span>
                        </div>
                    </div>
                    <p class="improvement-detail"><strong>Suggestion:</strong> ${esc(item.suggestion || '')}</p>
                    ${item.file_to_add ? `<p class="improvement-detail"><strong>File:</strong> ${esc(item.file_to_add)}</p>` : ''}
                    ${item.code_example ? `<div class="code-block">${esc(item.code_example)}</div>` : ''}
                </div>
            `).join('')}
        </div>
    `;
}

function renderQualityIssues(items) {
    if (!items.length) return '';
    return `
        <div class="result-card">
            <h3><i class="fas fa-shield-halved"></i> Code Quality Issues</h3>
            ${items.map(item => `
                <div class="weakness-item">
                    <div class="wi-title">${esc(item.issue || '')}</div>
                    <div class="wi-meta">${esc(item.location || '')} | <span class="priority-badge priority-${priorityClass(item.priority)}">${esc(item.priority || 'Medium')}</span></div>
                    <div class="wi-desc">${esc(item.problem || '')}</div>
                    ${item.suggestion ? `<div class="wi-suggestion">${esc(item.suggestion)}</div>` : ''}
                </div>
            `).join('')}
        </div>
    `;
}

function renderFileStats(stats) {
    const types = Object.entries(stats.file_types || {});
    return `
        <div class="result-card">
            <h3><i class="fas fa-folder-open"></i> File Statistics</h3>
            <div class="stats-grid">
                <div class="stat-item"><div class="stat-value">${stats.total_files || 0}</div><div class="stat-label">Readable Files</div></div>
                <div class="stat-item"><div class="stat-value">${stats.total_size_kb || 0}</div><div class="stat-label">Total KB</div></div>
                <div class="stat-item"><div class="stat-value">${stats.reviewed_file_limit || 15}</div><div class="stat-label">AI File Limit</div></div>
            </div>
            ${types.length ? `<div class="arch-tags stats-tags">${types.map(([type, count]) => `<span class="arch-tag">.${esc(type)} x ${count}</span>`).join('')}</div>` : ''}
        </div>
    `;
}

function renderSetupInstructions(instructions) {
    if (!instructions) return '';
    return `
        <div class="result-card warning-card">
            <h3><i class="fas fa-triangle-exclamation"></i> Setup Instructions</h3>
            <p><strong>Gemini:</strong> ${esc(instructions.gemini || '')}</p>
            <p><strong>LM Studio:</strong> ${esc(instructions.lm_studio || '')}</p>
        </div>
    `;
}

function showError(message) {
    const section = document.getElementById('results');
    const container = document.getElementById('results-content');
    container.innerHTML = `
        <div class="result-card warning-card">
            <h3><i class="fas fa-circle-exclamation"></i> Analysis Failed</h3>
            <p>${esc(message)}</p>
        </div>
    `;
    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function downloadReport() {
    if (!analysisData) return;
    const report = {
        timestamp: new Date().toISOString(),
        input: {
            mode: currentMode,
            topic: document.getElementById('project-topic').value,
            problem_statement: document.getElementById('problem-statement').value,
            custom_requirements: document.getElementById('custom-requirements').value,
        },
        analysis: analysisData,
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `project-analysis-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(link.href);
}

function esc(value) {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    return div.innerHTML;
}

function clampScore(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return 0;
    return Math.max(0, Math.min(100, Math.round(number)));
}

function ringColor(score) {
    if (score >= 80) return 'var(--green)';
    if (score >= 60) return 'var(--blue)';
    if (score >= 40) return 'var(--yellow)';
    return 'var(--red)';
}

function gradeClass(grade) {
    const first = String(grade || 'F')[0].toUpperCase();
    return ({ A: 'grade-A', B: 'grade-B', C: 'grade-C', D: 'grade-D' })[first] || 'grade-F';
}

function gradeForScore(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C+';
    if (score >= 60) return 'C';
    if (score >= 50) return 'D';
    return 'F';
}

function verdictClass(verdict) {
    const value = String(verdict || '').toLowerCase();
    if (value.includes('good')) return 'assessment-good';
    if (value.includes('poor')) return 'assessment-needs';
    return 'assessment-needs';
}

function statusClass(status) {
    const value = String(status || '').toLowerCase();
    if (value === 'implemented') return 'status-yes';
    if (value === 'partial') return 'status-partial';
    return 'status-no';
}

function qualityClass(quality) {
    const value = String(quality || '').toLowerCase();
    if (value.includes('good') || value.includes('excellent')) return 'quality-good';
    if (value.includes('n/a')) return 'quality-muted';
    return 'quality-poor';
}

function priorityClass(priority) {
    const value = String(priority || 'medium').toLowerCase();
    if (value.includes('high')) return 'high';
    if (value.includes('low')) return 'low';
    return 'medium';
}

function providerLabel(provider) {
    if (provider === 'gemini') return 'Analyzed with Gemini';
    if (provider === 'gemini_plus_lm_studio') return 'Combined Gemini + LM Studio';
    if (provider === 'lm_studio') return 'Analyzed with LM Studio';
    if (provider === 'lm_studio_chunked') return 'Analyzed with LM Studio chunks';
    if (provider === 'lm_studio_chunked_synthesized') return 'Synthesized from LM Studio chunks';
    if (provider === 'static_fallback') return 'Static fallback analysis';
    return 'No AI provider available';
}
